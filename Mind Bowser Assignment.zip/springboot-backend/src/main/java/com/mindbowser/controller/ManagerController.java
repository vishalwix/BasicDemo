package com.mindbowser.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindbowser.exception.ResourceNotFoundException;
import com.mindbowser.model.Manager;
import com.mindbowser.repository.ManagerRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class ManagerController {

	@Autowired
	private ManagerRepository managerRepository;
	
	// get all manager
	@GetMapping("/manager")
	public List<Manager> getAllManager(){
		return managerRepository.findAll();
	}		
	
	// create manager rest 
	@PostMapping("/manager")
	public Manager createManager(@RequestBody Manager manager) {
		return managerRepository.save(manager);
	}
	
	// get manager by id rest 
	@GetMapping("/manager/{id}")
	public ResponseEntity<Manager> getManagerById(@PathVariable Long id) {
		Manager manager = managerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Manager not exist with id :" + id));
		return ResponseEntity.ok(manager);
	}
	
	
}
