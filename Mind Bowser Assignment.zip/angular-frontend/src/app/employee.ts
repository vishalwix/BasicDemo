export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    address: string;
    dob: string;
    mobile: string;
    city: string;
}
