export class Manager {
  id: number;
  firstName: string;
  lastName: string;
  address: string;
  dob: string;
  email: string;
  password: string;
  company: string;
}
