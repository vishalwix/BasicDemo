import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Manager } from './manager';

@Injectable({
  providedIn: 'root'
})
export class ManagerService {

  private baseURL = "http://localhost:8080/api/v1/manager";

  constructor(private httpClient: HttpClient) { }

  getManagerList(): Observable<Manager[]>{
    return this.httpClient.get<Manager[]>(`${this.baseURL}`);
  }

  createManager(manager: Manager): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, manager);
  }

  getManagerById(id: number): Observable<Manager>{
    return this.httpClient.get<Manager>(`${this.baseURL}/${id}`);
  }
}
