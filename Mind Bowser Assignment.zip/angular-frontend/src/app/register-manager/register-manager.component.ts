import { Component, OnInit } from '@angular/core';
import { Manager } from '../manager';
import { ManagerService } from '../manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-manager',
  templateUrl: './register-manager.component.html',
  styleUrls: ['./register-manager.component.css']
})
export class RegisterManagerComponent implements OnInit {

  manager: Manager = new Manager();
  constructor(private managerService: ManagerService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveManager(){
    this.managerService.createManager(this.manager).subscribe( data =>{
      console.log(data);
      this.goToManagerList();
    },
    error => console.log(error));
  }

  goToManagerList(){
    this.router.navigate(['/employees']);
  }

  onSubmit(){
    console.log(this.manager);
    this.saveManager();
  }
}

